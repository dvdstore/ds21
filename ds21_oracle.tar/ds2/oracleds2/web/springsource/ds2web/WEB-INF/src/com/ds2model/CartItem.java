package com.ds2model;


//This class is used to bind one of the model objects to Form/html in jsp
public class CartItem
{
	private String str_Item;
	
	public String getStr_Item()
	{
		return str_Item;
	}
	
	public void setStr_Item(String prm_str_item)
	{
		this.str_Item = prm_str_item;
	}
	
}