package com.ds2model;

public class CheckOutItem
{
	private String item;
	private String quantity;
	private String title;
	private String actor;
	private String price;
	
	public String getItem()
	{
		return item;
	}
	
	public void setItem(String prm_item)
	{
		this.item =  prm_item;
	}
	
	public String getQuantity()
	{
		return quantity;
	}
	
	public void setQuantity(String prm_quantity)
	{
		this.quantity =  prm_quantity;
	}
	
	public String getTitle()
	{
		return title;
	}
	
	public void setTitle(String prm_title)
	{
		this.title =  prm_title;
	}
	
	public String getActor()
	{
		return actor;
	}
	
	public void setActor(String prm_actor)
	{
		this.actor =  prm_actor;
	}
	
	public String getPrice()
	{
		return price;
	}
	
	public void setPrice(String prm_price)
	{
		this.price =  prm_price;
	}
	
}