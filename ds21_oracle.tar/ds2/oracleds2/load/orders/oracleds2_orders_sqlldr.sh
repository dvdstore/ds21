sqlldr ds2/ds2 CONTROL=jan_orders.ctl, LOG=jan_orders.log, BAD=jan_orders.bad, DATA=../../../data_files/orders/jan_orders.csv & 
sqlldr ds2/ds2 CONTROL=feb_orders.ctl, LOG=feb_orders.log, BAD=feb_orders.bad, DATA=../../../data_files/orders/feb_orders.csv & 
sqlldr ds2/ds2 CONTROL=mar_orders.ctl, LOG=mar_orders.log, BAD=mar_orders.bad, DATA=../../../data_files/orders/mar_orders.csv & 
sqlldr ds2/ds2 CONTROL=apr_orders.ctl, LOG=apr_orders.log, BAD=apr_orders.bad, DATA=../../../data_files/orders/apr_orders.csv & 
sqlldr ds2/ds2 CONTROL=may_orders.ctl, LOG=may_orders.log, BAD=may_orders.bad, DATA=../../../data_files/orders/may_orders.csv & 
sqlldr ds2/ds2 CONTROL=jun_orders.ctl, LOG=jun_orders.log, BAD=jun_orders.bad, DATA=../../../data_files/orders/jun_orders.csv & 
sqlldr ds2/ds2 CONTROL=jul_orders.ctl, LOG=jul_orders.log, BAD=jul_orders.bad, DATA=../../../data_files/orders/jul_orders.csv & 
sqlldr ds2/ds2 CONTROL=aug_orders.ctl, LOG=aug_orders.log, BAD=aug_orders.bad, DATA=../../../data_files/orders/aug_orders.csv & 
sqlldr ds2/ds2 CONTROL=sep_orders.ctl, LOG=sep_orders.log, BAD=sep_orders.bad, DATA=../../../data_files/orders/sep_orders.csv & 
sqlldr ds2/ds2 CONTROL=oct_orders.ctl, LOG=oct_orders.log, BAD=oct_orders.bad, DATA=../../../data_files/orders/oct_orders.csv & 
sqlldr ds2/ds2 CONTROL=nov_orders.ctl, LOG=nov_orders.log, BAD=nov_orders.bad, DATA=../../../data_files/orders/nov_orders.csv & 
sqlldr ds2/ds2 CONTROL=dec_orders.ctl, LOG=dec_orders.log, BAD=dec_orders.bad, DATA=../../../data_files/orders/dec_orders.csv  
