sqlldr ds2/ds2 CONTROL=inv.ctl, LOG=inv.log, BAD=inv.bad, DATA=../../../data_files/prod/inv.csv 
