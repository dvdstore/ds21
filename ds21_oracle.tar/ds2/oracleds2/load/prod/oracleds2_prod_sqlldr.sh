sqlldr ds2/ds2 CONTROL=prod.ctl, LOG=prod.log, BAD=prod.bad, DATA=../../../data_files/prod/prod.csv 
