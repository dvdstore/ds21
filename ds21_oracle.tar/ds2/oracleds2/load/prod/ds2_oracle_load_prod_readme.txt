ds2_oracle_load_prod_readme.txt

Instructions for loading DVD Store Version 2 (DS2) database product data
(assumes data files are in directory ./ds2/data_files/prod)

 sh oracleds2_prod_sqlldr.sh
 sh oracleds2_inv_sqlldr.sh

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  9/8/05
