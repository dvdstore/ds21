ds2_oracle_load_cust_readme.txt

Instructions for loading DVD Store Version 2 (DS2) database customer data
(assumes data files are in directory ./ds2/data_files/cust)

sh oracleds2_cust_sqlldr.sh

For Oracle Standard edition use files in standard directory

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  9/8/05
