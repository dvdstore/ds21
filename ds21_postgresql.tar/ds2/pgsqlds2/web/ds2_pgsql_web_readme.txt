ds2_pgsql_web_readme.txt

The PostgreSQL DVD Store currently has two web application interfaces, PHP abd JSP

For the ds2webdriver program and source, see ./ds2/drivers

Directories
-----------
./ds2/pgsqlds2/web
./ds2/pgsqlds2/web/php         php pages 
./ds2/pgsqlds2/web/jsp         jsp pages 

<jshah@vmware.com> and <tmuirhead@vmware.com>  11/1/11
