select * from pg_stat_activity;
