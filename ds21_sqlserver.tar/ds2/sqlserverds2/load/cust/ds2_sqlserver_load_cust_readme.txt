ds2_sqlserver_load_cust_readme.txt

Instructions for loading DVD Store Version 2 (DS2) database customer data
(assumes data files are in directory c:\ds2\data_files\cust)

  osql -Usa -P -i sqlserverds2_load_cust.sql

<dave_jaffe@dell.com> and <tmuirhead@vmware.com>  6/28/05
